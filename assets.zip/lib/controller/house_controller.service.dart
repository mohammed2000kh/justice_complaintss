
import 'package:get/get.dart';

class HouseController extends GetxController {
}
